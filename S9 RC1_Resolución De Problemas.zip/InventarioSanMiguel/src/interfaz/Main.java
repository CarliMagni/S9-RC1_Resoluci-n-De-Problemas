package interfaz;
/** Punto de entrada del sistema. */
public class Main {
    public static void main(String[] args) { new MenuConsola().iniciar(); }
}
