package interfaz;
import negocio.GestorInventario;
import negocio.InventarioException;
import modelo.Producto;
import modelo.ProductoPerecedero;
import modelo.ProductoNoPerecedero;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/** Menu de consola; delega las reglas de inventario al gestor. */
public class MenuConsola {
    private final GestorInventario gestor = new GestorInventario();
    private final Scanner scanner = new Scanner(System.in);
    public void iniciar() {
        boolean continuar = true;
        while (continuar) {
            mostrarMenu();
            String opcion = scanner.nextLine().trim();
            try {
                switch (opcion) {
                    case "1": registrarProducto(); break;
                    case "2": consultarInventario(); break;
                    case "3": buscarProducto(); break;
                    case "4": actualizarExistencias(); break;
                    case "5": mostrarAlertas(); break;
                    case "6": mostrarValorInventario(); break;
                    case "0": continuar = false; System.out.println("Hasta pronto."); break;
                    default: System.out.println("Opcion no valida.");
                }
            } catch (IllegalArgumentException | InventarioException ex) {
                System.out.println("ERROR: " + ex.getMessage());
            }
        }
    }
    private void mostrarMenu() {
        System.out.println("\n=== INVENTARIO COMERCIAL SAN MIGUEL ===");
        System.out.println("1. Registrar producto");
        System.out.println("2. Consultar inventario");
        System.out.println("3. Buscar producto por codigo");
        System.out.println("4. Registrar entrada o salida");
        System.out.println("5. Alertas de stock y vencimientos");
        System.out.println("6. Valor total del inventario");
        System.out.println("0. Salir");
        System.out.print("Opcion: ");
    }
    private String leerObligatorio(String etiqueta) {
        System.out.print(etiqueta + ": ");
        String texto = scanner.nextLine().trim();
        if (texto.isEmpty()) throw new IllegalArgumentException(etiqueta + " es obligatorio");
        return texto;
    }
    private int leerEntero(String etiqueta) {
        String texto = leerObligatorio(etiqueta);
        try { return Integer.parseInt(texto); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException(etiqueta + " debe ser un entero"); }
    }
    private BigDecimal leerDecimal(String etiqueta) {
        String texto = leerObligatorio(etiqueta);
        try { return new BigDecimal(texto); }
        catch (NumberFormatException ex) { throw new IllegalArgumentException(etiqueta + " debe ser un numero decimal valido (usar punto)"); }
    }
    private LocalDate leerFecha(String etiqueta) {
        String texto = leerObligatorio(etiqueta + " (AAAA-MM-DD)");
        try { return LocalDate.parse(texto); }
        catch (DateTimeParseException ex) { throw new IllegalArgumentException("Fecha invalida; use AAAA-MM-DD"); }
    }
    private void registrarProducto() throws InventarioException {
        System.out.println("Tipo: 1 = Perecedero, 2 = No perecedero");
        int tipo = leerEntero("Tipo");
        if (tipo != 1 && tipo != 2) throw new IllegalArgumentException("Tipo invalido");
        String codigo = leerObligatorio("Codigo");
        String nombre = leerObligatorio("Nombre");
        String categoria = leerObligatorio("Categoria");
        int cantidad = leerEntero("Cantidad");
        BigDecimal precio = leerDecimal("Precio de venta");
        BigDecimal costo = leerDecimal("Costo unitario");
        int minimo = leerEntero("Stock minimo");
        Producto producto;
        if (tipo == 1) {
            LocalDate fecha = leerFecha("Fecha de vencimiento");
            producto = new ProductoPerecedero(codigo, nombre, categoria, cantidad, precio, costo, minimo, fecha);
        } else {
            producto = new ProductoNoPerecedero(codigo, nombre, categoria, cantidad, precio, costo, minimo);
        }
        gestor.registrarProducto(producto);
        System.out.println("Producto registrado correctamente.");
    }
    private void imprimirProductos(List<Producto> productos) {
        if (productos.isEmpty()) { System.out.println("No hay productos para mostrar."); return; }
        for (Producto p : productos) System.out.println(p.mostrarInformacion());
    }
    private void consultarInventario() { imprimirProductos(gestor.listarProductos()); }
    private void buscarProducto() {
        String codigo = leerObligatorio("Codigo a buscar");
        if (gestor.buscarPorCodigo(codigo).isPresent())
            System.out.println(gestor.buscarPorCodigo(codigo).get().mostrarInformacion());
        else System.out.println("Producto no encontrado.");
    }
    private void actualizarExistencias() throws InventarioException {
        System.out.println("1 = Entrada, 2 = Salida");
        int operacion = leerEntero("Operacion");
        if (operacion != 1 && operacion != 2) throw new IllegalArgumentException("Operacion invalida");
        String codigo = leerObligatorio("Codigo");
        int unidades = leerEntero("Unidades");
        if (operacion == 1) gestor.registrarEntrada(codigo, unidades);
        else gestor.registrarSalida(codigo, unidades);
        System.out.println("Existencias actualizadas correctamente.");
    }
    private void mostrarAlertas() {
        System.out.println("--- STOCK MINIMO ---");
        imprimirProductos(gestor.obtenerProductosBajoStock());
        System.out.println("--- VENCIDOS ---");
        imprimirProductos(gestor.obtenerProductosVencidos());
        System.out.println("--- PROXIMOS A VENCER (7 DIAS) ---");
        imprimirProductos(gestor.obtenerProximosAVencer(7));
    }
    private void mostrarValorInventario() {
        System.out.println("Valor total al costo: $" + gestor.calcularValorTotalInventario());
    }
}
