package negocio;
import modelo.Producto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Operaciones de inventario; no contiene lectura de consola. */
public class GestorInventario {
    private final Map<String, Producto> productos = new LinkedHashMap<>();
    public void registrarProducto(Producto producto) throws InventarioException {
        if (producto == null) throw new InventarioException("El producto no puede ser nulo");
        if (productos.containsKey(producto.getCodigo())) throw new InventarioException("Codigo duplicado: " + producto.getCodigo());
        productos.put(producto.getCodigo(), producto);
    }
    public Optional<Producto> buscarPorCodigo(String codigo) {
        if (codigo == null) return Optional.empty();
        return Optional.ofNullable(productos.get(codigo.trim()));
    }
    private Producto exigirProducto(String codigo) throws InventarioException {
        return buscarPorCodigo(codigo).orElseThrow(() -> new InventarioException("Producto inexistente: " + codigo));
    }
    public List<Producto> listarProductos() { return new ArrayList<>(productos.values()); }
    public void registrarEntrada(String codigo, int unidades) throws InventarioException {
        exigirProducto(codigo).aumentarStock(unidades);
    }
    public void registrarSalida(String codigo, int unidades) throws InventarioException {
        Producto producto = exigirProducto(codigo);
        try { producto.reducirStock(unidades); }
        catch (IllegalArgumentException ex) { throw new InventarioException(ex.getMessage()); }
    }
    public List<Producto> obtenerProductosBajoStock() {
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : productos.values()) if (p.estaBajoStock()) resultado.add(p);
        return resultado;
    }
    public List<Producto> obtenerProductosVencidos() {
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : productos.values()) if (p.estaVencido()) resultado.add(p);
        return resultado;
    }
    public List<Producto> obtenerProximosAVencer(int dias) {
        if (dias < 0) throw new IllegalArgumentException("Los dias no pueden ser negativos");
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : productos.values()) if (p.estaProximoAVencer(dias)) resultado.add(p);
        return resultado;
    }
    public BigDecimal calcularValorTotalInventario() {
        BigDecimal total = BigDecimal.ZERO;
        for (Producto p : productos.values()) total = total.add(p.calcularValorInventario());
        return total;
    }
}
