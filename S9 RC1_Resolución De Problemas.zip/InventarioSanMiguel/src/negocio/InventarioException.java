package negocio;
/** Error de reglas de inventario mostrado al usuario. */
public class InventarioException extends Exception {
    public InventarioException(String mensaje) { super(mensaje); }
}
