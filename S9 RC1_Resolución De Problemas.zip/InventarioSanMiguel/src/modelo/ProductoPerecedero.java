package modelo;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/** Producto que requiere control de fecha de vencimiento. */
public class ProductoPerecedero extends Producto {
    private LocalDate fechaVencimiento;
    private static final int DIAS_ALERTA = 7;
    public ProductoPerecedero(String codigo, String nombre, String categoria, int cantidad,
                              BigDecimal precioVenta, BigDecimal costoUnitario, int stockMinimo,
                              LocalDate fechaVencimiento) {
        super(codigo, nombre, categoria, cantidad, precioVenta, costoUnitario, stockMinimo);
        setFechaVencimiento(fechaVencimiento);
    }
    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
    public void setFechaVencimiento(LocalDate fecha) {
        if (fecha == null) throw new IllegalArgumentException("La fecha de vencimiento es obligatoria");
        fechaVencimiento = fecha;
    }
    public long diasParaVencer() { return ChronoUnit.DAYS.between(LocalDate.now(), fechaVencimiento); }
    @Override public boolean estaVencido() { return fechaVencimiento.isBefore(LocalDate.now()); }
    @Override public boolean estaProximoAVencer(int dias) {
        if (dias < 0) throw new IllegalArgumentException("Los dias no pueden ser negativos");
        return !estaVencido() && diasParaVencer() <= dias;
    }
    @Override public TipoProducto getTipo() { return TipoProducto.PERECEDERO; }
    @Override public String obtenerEstado() {
        if (estaVencido()) return "VENCIDO";
        if (estaProximoAVencer(DIAS_ALERTA)) return "PROXIMO A VENCER";
        return "VIGENTE";
    }
    @Override public String mostrarInformacion() {
        return super.mostrarInformacion() + " | Vence: " + fechaVencimiento + " | Estado: " + obtenerEstado();
    }
}
