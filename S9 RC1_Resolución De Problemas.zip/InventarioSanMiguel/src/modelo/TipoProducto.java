package modelo;
public enum TipoProducto { PERECEDERO, NO_PERECEDERO }
