package modelo;
import java.math.BigDecimal;
import java.time.LocalDate;

/** Datos y operaciones comunes de todos los productos. */
public abstract class Producto {
    private final String codigo;
    private String nombre, categoria;
    private int cantidad, stockMinimo;
    private BigDecimal precioVenta, costoUnitario;
    private final LocalDate fechaRegistro;

    protected Producto(String codigo, String nombre, String categoria, int cantidad,
                       BigDecimal precioVenta, BigDecimal costoUnitario, int stockMinimo) {
        if (codigo == null || codigo.trim().isEmpty()) throw new IllegalArgumentException("El codigo es obligatorio");
        this.codigo = codigo.trim();
        setNombre(nombre); setCategoria(categoria); setCantidad(cantidad);
        setPrecioVenta(precioVenta); setCostoUnitario(costoUnitario); setStockMinimo(stockMinimo);
        this.fechaRegistro = LocalDate.now();
    }
    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getCategoria() { return categoria; }
    public int getCantidad() { return cantidad; }
    public int getStockMinimo() { return stockMinimo; }
    public BigDecimal getPrecioVenta() { return precioVenta; }
    public BigDecimal getCostoUnitario() { return costoUnitario; }
    public LocalDate getFechaRegistro() { return fechaRegistro; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) throw new IllegalArgumentException("El nombre es obligatorio");
        this.nombre = nombre.trim();
    }
    public void setCategoria(String categoria) {
        if (categoria == null || categoria.trim().isEmpty()) throw new IllegalArgumentException("La categoria es obligatoria");
        this.categoria = categoria.trim();
    }
    public void setCantidad(int cantidad) {
        if (cantidad < 0) throw new IllegalArgumentException("La cantidad no puede ser negativa");
        this.cantidad = cantidad;
    }
    public void setPrecioVenta(BigDecimal precio) {
        if (precio == null || precio.signum() <= 0) throw new IllegalArgumentException("El precio debe ser mayor que cero");
        this.precioVenta = precio;
    }
    public void setCostoUnitario(BigDecimal costo) {
        if (costo == null || costo.signum() <= 0) throw new IllegalArgumentException("El costo debe ser mayor que cero");
        this.costoUnitario = costo;
    }
    public void setStockMinimo(int minimo) {
        if (minimo < 0) throw new IllegalArgumentException("El stock minimo no puede ser negativo");
        this.stockMinimo = minimo;
    }
    public void aumentarStock(int unidades) {
        if (unidades <= 0) throw new IllegalArgumentException("Las unidades deben ser mayores que cero");
        this.cantidad = Math.addExact(this.cantidad, unidades);
    }
    public void reducirStock(int unidades) {
        if (unidades <= 0) throw new IllegalArgumentException("Las unidades deben ser mayores que cero");
        if (unidades > cantidad) throw new IllegalArgumentException("No hay suficientes unidades disponibles");
        cantidad -= unidades;
    }
    public boolean estaBajoStock() { return cantidad <= stockMinimo; }
    public BigDecimal calcularValorInventario() { return costoUnitario.multiply(BigDecimal.valueOf(cantidad)); }
    public boolean estaVencido() { return false; }
    public boolean estaProximoAVencer(int dias) { return false; }
    public abstract TipoProducto getTipo();
    public abstract String obtenerEstado();
    public String mostrarInformacion() {
        return "Codigo: " + codigo + " | Nombre: " + nombre + " | Categoria: " + categoria
             + " | Cantidad: " + cantidad + " | Stock minimo: " + stockMinimo
             + " | Precio: $" + precioVenta + " | Costo: $" + costoUnitario
             + " | Fecha registro: " + fechaRegistro + " | Valor: $" + calcularValorInventario();
    }
}
