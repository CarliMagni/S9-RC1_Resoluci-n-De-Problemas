package modelo;
import java.math.BigDecimal;

/** Producto sin fecha de caducidad. */
public class ProductoNoPerecedero extends Producto {
    public ProductoNoPerecedero(String codigo, String nombre, String categoria, int cantidad,
                                BigDecimal precioVenta, BigDecimal costoUnitario, int stockMinimo) {
        super(codigo, nombre, categoria, cantidad, precioVenta, costoUnitario, stockMinimo);
    }
    @Override public TipoProducto getTipo() { return TipoProducto.NO_PERECEDERO; }
    @Override public String obtenerEstado() { return "SIN CADUCIDAD"; }
    @Override public String mostrarInformacion() {
        return super.mostrarInformacion() + " | Estado: " + obtenerEstado();
    }
}
