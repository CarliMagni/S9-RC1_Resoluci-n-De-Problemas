import modelo.*;
import negocio.*;
import java.math.BigDecimal;
import java.time.LocalDate;
public class PruebasInventario {
    private static int ok = 0;
    private static void verificar(boolean condicion, String nombre) {
        if (!condicion) throw new AssertionError(nombre);
        System.out.println("OK: " + nombre); ok++;
    }
    private static ProductoNoPerecedero np(String codigo, int cantidad) {
        return new ProductoNoPerecedero(codigo,"Detergente","Limpieza",cantidad,new BigDecimal("2.50"),new BigDecimal("1.25"),3);
    }
    public static void main(String[] args) throws Exception {
        GestorInventario g = new GestorInventario();
        g.registrarProducto(np("A1",5));
        verificar(g.listarProductos().size()==1,"RF1 Registro correcto");
        try { np("A2",-1); throw new AssertionError("Debio rechazar cantidad negativa"); }
        catch (IllegalArgumentException e) { verificar(true,"RF2 Cantidad negativa rechazada"); }
        try { new ProductoNoPerecedero("A2","","Limpieza",1,new BigDecimal("1"),new BigDecimal("1"),0); throw new AssertionError("Debio rechazar nombre vacio"); }
        catch (IllegalArgumentException e) { verificar(true,"RF2 Nombre vacio rechazado"); }
        try { g.registrarProducto(np("A1",2)); throw new AssertionError("Debio rechazar duplicado"); }
        catch (InventarioException e) { verificar(true,"RF2 Codigo duplicado rechazado"); }
        verificar(g.listarProductos().get(0).getCodigo().equals("A1"),"RF3 Listado de productos");
        verificar(g.buscarPorCodigo("A1").isPresent() && !g.buscarPorCodigo("NO").isPresent(),"RF4 Busqueda por codigo");
        g.registrarEntrada("A1",2);
        verificar(g.buscarPorCodigo("A1").get().getCantidad()==7,"RF5 Entrada de unidades");
        g.registrarSalida("A1",5);
        verificar(g.buscarPorCodigo("A1").get().getCantidad()==2,"RF5 Salida de unidades");
        try { g.registrarSalida("A1",99); throw new AssertionError("Debio rechazar salida excesiva"); }
        catch (InventarioException e) { verificar(g.buscarPorCodigo("A1").get().getCantidad()==2,"RF5 Salida excesiva no altera stock"); }
        verificar(g.obtenerProductosBajoStock().size()==1,"RF6 Alerta stock minimo");
        g.registrarProducto(new ProductoPerecedero("P1","Leche","Lacteos",2,new BigDecimal("2.00"),new BigDecimal("1.00"),1,LocalDate.now().minusDays(1)));
        g.registrarProducto(new ProductoPerecedero("P2","Yogur","Lacteos",2,new BigDecimal("2.00"),new BigDecimal("1.00"),1,LocalDate.now().plusDays(3)));
        verificar(g.obtenerProductosVencidos().size()==1,"RF7 Producto vencido");
        verificar(g.obtenerProximosAVencer(7).size()==1,"RF7 Producto proximo a vencer");
        verificar(g.calcularValorTotalInventario().compareTo(new BigDecimal("6.50"))==0,"RF8 Valor total al costo $6.50");
        System.out.println("TOTAL: " + ok + " pruebas superadas");
    }
}
